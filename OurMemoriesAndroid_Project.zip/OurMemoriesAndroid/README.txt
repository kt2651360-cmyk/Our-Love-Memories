OUR MEMORIES — Android Studio project

Features:
- Pink romantic photo-memory gallery
- Pick photos from the phone
- Add a caption and saved date
- Tap a photo to view it
- Delete a saved memory
- Stores the photo references and captions locally on the device

Build an APK:
1. Install Android Studio on a computer.
2. Open this folder in Android Studio.
3. Let Gradle sync and install any requested Android SDK components.
4. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Find the APK under app/build/outputs/apk/debug/.

Note:
This ZIP is the Android Studio source project, not a precompiled APK.
Photos remain on the device; uninstalling the app or deleting source photos may affect access.
