package com.example.ourmemories

import android.content.Context
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import org.json.JSONArray
import org.json.JSONObject

private val Pink = Color(0xFFFF6F9F)
private val PalePink = Color(0xFFFFF0F5)
private val DeepPink = Color(0xFFB83268)
private val Ink = Color(0xFF492638)

data class Memory(val uri: String, val caption: String, val date: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { OurMemoriesApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OurMemoriesApp() {
    val context = LocalContext.current
    var memories by remember { mutableStateOf(loadMemories(context)) }
    var selectedUri by remember { mutableStateOf<Uri?>(null) }
    var caption by remember { mutableStateOf("") }
    var showAdd by remember { mutableStateOf(false) }
    var selectedMemory by remember { mutableStateOf<Memory?>(null) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try { context.contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            selectedUri = uri
            caption = ""
            showAdd = true
        }
    }

    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Pink, secondary = DeepPink, background = PalePink,
            surface = Color.White, onPrimary = Color.White, onBackground = Ink
        )
    ) {
        Scaffold(
            containerColor = PalePink,
            topBar = {
                CenterAlignedTopAppBar(
                    title = {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("Our Memories", fontWeight = FontWeight.Bold, color = DeepPink, fontSize = 22.sp)
                            Text("little moments, forever ❤️", color = Ink.copy(alpha = .65f), fontSize = 11.sp)
                        }
                    },
                    colors = TopAppBarDefaults.centerAlignedTopAppBarColors(containerColor = PalePink)
                )
            },
            floatingActionButton = {
                FloatingActionButton(
                    onClick = { picker.launch(arrayOf("image/*")) },
                    containerColor = Pink, contentColor = Color.White
                ) { Icon(Icons.Default.Add, contentDescription = "Add photo") }
            }
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp)) {
                Spacer(Modifier.height(8.dp))
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    shape = RoundedCornerShape(22.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(Modifier.padding(18.dp)) {
                        Text("Our little world 💗", color = DeepPink, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        Spacer(Modifier.height(4.dp))
                        Text("သိမ်းထားချင်တဲ့ အမှတ်တရပုံလေးတွေ ဒီနေရာမှာ စုထားပါ။", color = Ink, fontSize = 13.sp)
                        Spacer(Modifier.height(10.dp))
                        Text("${memories.size} memories saved", color = Pink, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                    }
                }
                Spacer(Modifier.height(16.dp))
                if (memories.isEmpty()) {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("💌", fontSize = 48.sp)
                            Spacer(Modifier.height(8.dp))
                            Text("Your story starts here", color = DeepPink, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                            Text("အောက်က + ကိုနှိပ်ပြီး ပထမဆုံးပုံလေးထည့်ပါ", color = Ink.copy(alpha = .7f), fontSize = 12.sp)
                        }
                    }
                } else {
                    LazyVerticalGrid(
                        columns = GridCells.Fixed(2),
                        contentPadding = PaddingValues(bottom = 90.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        items(memories) { memory ->
                            Card(
                                modifier = Modifier.fillMaxWidth().clickable { selectedMemory = memory },
                                shape = RoundedCornerShape(18.dp),
                                colors = CardDefaults.cardColors(containerColor = Color.White)
                            ) {
                                Column {
                                    AsyncImage(
                                        model = Uri.parse(memory.uri),
                                        contentDescription = memory.caption,
                                        modifier = Modifier.fillMaxWidth().height(150.dp),
                                        contentScale = ContentScale.Crop
                                    )
                                    Column(Modifier.padding(10.dp)) {
                                        Text(memory.caption.ifBlank { "A lovely moment ❤️" }, color = Ink, fontWeight = FontWeight.SemiBold, maxLines = 2, fontSize = 13.sp)
                                        Text(memory.date, color = Pink, fontSize = 10.sp)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        if (showAdd && selectedUri != null) {
            AlertDialog(
                onDismissRequest = { showAdd = false; selectedUri = null },
                title = { Text("Add a memory 💗", color = DeepPink, fontWeight = FontWeight.Bold) },
                text = {
                    Column {
                        AsyncImage(model = selectedUri, contentDescription = null, modifier = Modifier.fillMaxWidth().height(150.dp).clip(RoundedCornerShape(14.dp)), contentScale = ContentScale.Crop)
                        Spacer(Modifier.height(12.dp))
                        OutlinedTextField(value = caption, onValueChange = { caption = it }, label = { Text("ဒီပုံရဲ့ အမှတ်တရစာလေး") }, placeholder = { Text("ဥပမာ - ပထမဆုံးအတူသွားခဲ့တဲ့နေ့") }, singleLine = false)
                    }
                },
                confirmButton = {
                    TextButton(onClick = {
                        val item = Memory(selectedUri.toString(), caption.trim(), java.text.SimpleDateFormat("dd MMM yyyy", java.util.Locale.getDefault()).format(java.util.Date()))
                        memories = listOf(item) + memories
                        saveMemories(context, memories)
                        showAdd = false; selectedUri = null
                    }) { Text("Save ❤️", color = DeepPink) }
                },
                dismissButton = { TextButton(onClick = { showAdd = false; selectedUri = null }) { Text("Cancel") } }
            )
        }

        selectedMemory?.let { memory ->
            AlertDialog(
                onDismissRequest = { selectedMemory = null },
                title = { Text("A lovely memory ❤️", color = DeepPink, fontWeight = FontWeight.Bold) },
                text = {
                    Column {
                        AsyncImage(model = Uri.parse(memory.uri), contentDescription = null, modifier = Modifier.fillMaxWidth().height(230.dp).clip(RoundedCornerShape(14.dp)), contentScale = ContentScale.Fit)
                        Spacer(Modifier.height(10.dp))
                        Text(memory.caption.ifBlank { "A lovely moment ❤️" }, color = Ink)
                        Text(memory.date, color = Pink, fontSize = 12.sp)
                    }
                },
                confirmButton = {
                    TextButton(onClick = {
                        memories = memories.filterNot { it.uri == memory.uri }
                        saveMemories(context, memories)
                        selectedMemory = null
                    }) { Icon(Icons.Default.Delete, contentDescription = null, tint = DeepPink); Text(" Delete", color = DeepPink) }
                },
                dismissButton = { TextButton(onClick = { selectedMemory = null }) { Text("Close") } }
            )
        }
    }
}

private fun loadMemories(context: Context): List<Memory> {
    return try {
        val raw = context.getSharedPreferences("our_memories", Context.MODE_PRIVATE).getString("items", "[]") ?: "[]"
        val array = JSONArray(raw)
        (0 until array.length()).map { i ->
            val obj = array.getJSONObject(i)
            Memory(obj.getString("uri"), obj.optString("caption"), obj.optString("date"))
        }
    } catch (_: Exception) { emptyList() }
}

private fun saveMemories(context: Context, memories: List<Memory>) {
    val array = JSONArray()
    memories.forEach {
        array.put(JSONObject().put("uri", it.uri).put("caption", it.caption).put("date", it.date))
    }
    context.getSharedPreferences("our_memories", Context.MODE_PRIVATE).edit().putString("items", array.toString()).apply()
}
